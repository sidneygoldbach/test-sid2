
# Multilingual Personality Evaluation App

This is a full-stack web application that presents themed personality questions to users, analyzes their answers, and provides personalized advice after payment. The app supports multiple languages and is fully database-driven.

---

## 🧱 Backend Setup (Flask + SQLite)

### Requirements
- Python 3.8+
- Flask
- SQLAlchemy

### Installation
```bash
cd backend
pip install flask sqlalchemy
python main.py
```

This will start the Flask server at `http://localhost:5000`.

---

## 🎨 Frontend Setup (React + Tailwind CSS + i18n)

### Requirements
- Node.js
- npm or yarn

### Installation
```bash
cd frontend
npm install
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init
```

Replace the generated `tailwind.config.js` with the one provided.

Ensure your `src/index.css` includes:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### Run the App
```bash
npm start
```

This will start the React app at `http://localhost:3000`.

---

## 🌐 Multilingual Support
Translations are stored in:
```
frontend/src/i18n/locales/en.json
frontend/src/i18n/locales/es.json
```
You can add more languages by extending these files and updating `i18n.js`.

---

## 💳 Stripe Integration
The payment flow is simulated. Replace the dummy Stripe logic in `Payment.js` with actual Stripe API calls.

---

## 🗃️ Database
Uses SQLite for development. You can switch to PostgreSQL by updating the connection string in `config.py`.

---

## 📁 File Structure
```
backend/
  models.py
  config.py
  routes.py
  main.py
frontend/
  tailwind.config.js
  src/
    App.js
    index.css
    i18n/
    pages/
```

---

## ✅ Status
- Backend: Complete
- Frontend: Complete
- Multilingual: Enabled
- Payment: Simulated
- Database: SQLite (PostgreSQL-ready)

