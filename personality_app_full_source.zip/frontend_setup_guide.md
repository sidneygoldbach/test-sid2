
# 🔗 Wiring Up React Frontend with Flask Backend

## 1. Flask Backend Configuration

### Enable CORS
Install Flask-CORS to allow requests from React:
```bash
pip install flask-cors
```

Update `main.py`:
```python
from flask import Flask
from flask_cors import CORS
from routes import api

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
app.register_blueprint(api)

if __name__ == '__main__':
    app.run(debug=True)
```

---

## 2. React Frontend Configuration

### Proxy Setup
Add the following to `frontend/package.json` to proxy API requests to Flask:
```json
"proxy": "http://localhost:5000"
```
This allows you to use relative paths like `/themes` or `/submit` in fetch calls.

---

## 3. Running the App Locally

### Start Flask Backend
```bash
cd backend
python main.py
```

### Start React Frontend
```bash
cd frontend
npm start
```

React will run on `http://localhost:3000` and proxy API requests to Flask running on `http://localhost:5000`.

---

## ✅ Notes
- Ensure both servers are running simultaneously.
- Use consistent language codes (e.g., `lang=en`) in API calls.
- Replace dummy user IDs and Stripe transaction IDs with real logic in production.
